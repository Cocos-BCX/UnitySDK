//
//  RIPEMD160Diggest.h
//  CocosSDK
//
//  Created by SYLing on 2019/3/6.
//

#import "Diggest.h"

@interface RIPEMD160Diggest : Diggest

@end
