//
//  WordList.h
//  CocosSDK
//
//  Created by SYLing on 2019/3/13.
//

#import <Foundation/Foundation.h>

extern const char* word_list[];
extern const uint32_t word_list_size;
