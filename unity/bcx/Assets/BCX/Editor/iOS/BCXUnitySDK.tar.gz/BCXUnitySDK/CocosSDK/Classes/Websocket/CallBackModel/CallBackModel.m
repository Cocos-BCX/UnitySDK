//
//  CallBackModel.m
//  CocosSDK
//
//  Created by SYLing on 2019/3/6.
//

#import "CallBackModel.h"

@implementation CallBackModel

@end
