//
//  SHA256Diggest.h
//  CocosSDK
//
//  Created by SYLing on 2019/3/6.
//

#import "Diggest.h"
/**
 Sha256 algorithm implementation (can be replaced by C code of the system)
 */
@interface SHA256Diggest : Diggest



@end
